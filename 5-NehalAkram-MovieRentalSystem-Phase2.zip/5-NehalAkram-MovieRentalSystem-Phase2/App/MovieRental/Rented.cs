public class Rented
{
    public DateTime rentDate;
    public DateTime returnDate;
}