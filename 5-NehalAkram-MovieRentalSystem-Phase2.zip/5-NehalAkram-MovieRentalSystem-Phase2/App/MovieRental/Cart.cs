public class Cart
{
    public List<movieItem> moviesInCart { get; set; }
    public int UID;
    public double total = 0;
}