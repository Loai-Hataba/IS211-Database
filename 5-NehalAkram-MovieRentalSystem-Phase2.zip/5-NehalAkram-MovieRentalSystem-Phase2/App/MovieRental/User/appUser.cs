namespace MovieRental.User
{
    public class appUser
    {
        public int UID;
        public string name;
        public string email;
        public string phoneNum;
        public string address;
        public string businessAdress;
        public string password;
        public bool isAdmin = false;
    }
}