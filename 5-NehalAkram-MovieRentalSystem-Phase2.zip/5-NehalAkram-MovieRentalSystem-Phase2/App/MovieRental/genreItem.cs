public class genreItem
{
    public int id { get; set; }
    public string title { get; set; }
}